import rollbar

rollbar.init('a19ab01f982244c6a85d168e5c41ad4c')
try:
    1/0
except Exception:
    rollbar.report_exc_info()