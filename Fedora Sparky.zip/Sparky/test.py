import rollbar
rollbar.init('a19ab01f982244c6a85d168e5c41ad4c')
try:
	from run import app
	import unittest
    
    # delete before prod deploy
except Exception as e:
	print(f"Module missing {e}\n")
    # rollbar.report_exc_info()

class FlaskTest(unittest.TestCase):
	try:
		def test_index(self): #check response 200
			test  =  app.test_client(self)
			resp  =  test.get("/")
			code  =  resp.status_code
			self.assertEqual(code,111)
		def test_index_content(self): #check if json
			test  =  app.test_client(self)
			resp  =  test.get("/")
			self.assertEqual(resp.content_type,"application/json")
		def test_index_data(self): #check for a content in response
			test  =  app.test_client(self)
			resp  =  test.get("/")
			self.assertTrue(b'bot' in resp.data)
	except Exception:
		rollbar.report_exc_info()
if __name__ == '__main__':
    try:
        unittest.main()
    except Exception:
        rollbar.report_exc_info()
    
