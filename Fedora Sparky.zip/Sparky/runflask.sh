clear

curl --header "Content-Type: application/json"        \
--request GET   \
--data  '{"ply":"susi","dim":"23,10","pp":"6,4","tp":"3,2","dist":"23"}' http://localhost:5000/
#--data  '{"ply":"bot","dim":"31,22","pp":"11,12","tp":"21,22","dist":"40"}' \

# [23,10],[6,4],[3,2],23)



