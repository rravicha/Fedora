# from engine import Engine
from flask import Flask, jsonify, request 

app = Flask(__name__) 
  
# on the terminal type: curl http://127.0.0.1:5000/ 
# returns hello world when we use GET. 
# returns the data that we send when we use POST. 
@app.route('/', methods = ['GET', 'POST']) 
def home(): 
    if(request.method == 'GET'): 
  
        data = "provide inputs dimensions, captain_position, badguy_position, distance delimited by tilde"
        return jsonify({'data': data}) 

@app.route('/home/<int:num>', methods = ['GET']) 
def disp(num): 
  
    return jsonify({'data': num}) 
  
  
# driver function 
if __name__ == '__main__': 
  
    app.run(debug = True) 