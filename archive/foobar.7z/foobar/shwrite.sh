import glob
f=open('run.sh','w')
for file in glob.glob('*.py'):
 print(file)  
#f.writelines('python3'+' '+file)
f.close()
