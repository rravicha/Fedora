

__author__ = "Raghavendran Ravichandran"
__copyright__ = "Copyright 2020, Sparkly Studio"
__version__ = "1.0"


